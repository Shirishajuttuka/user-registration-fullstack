package com.example.peanutapp.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.peanutapp.R
import com.example.peanutapp.api.ApiClient
import com.example.peanutapp.api.ApiService
import com.example.peanutapp.model.LoginResponse
import com.example.peanutapp.utils.SessionManager
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val loginBtn = findViewById<Button>(R.id.btnLogin)

        loginBtn.setOnClickListener {
            performLogin()
        }
    }

    private fun performLogin() {

        val requestBody = mapOf(
            "login" to "2088888",
            "password" to "ral11lod"
        )

        val apiService = ApiClient.retrofit.create(ApiService::class.java)

        apiService.login(requestBody)
            .enqueue(object : Callback<LoginResponse> {

                override fun onResponse(
                    call: Call<LoginResponse>,
                    response: Response<LoginResponse>
                ) {
                    if (response.isSuccessful && response.body() != null) {
                        val token = response.body()!!.token
                        SessionManager(this@LoginActivity).saveToken(token)

                        startActivity(
                            Intent(this@LoginActivity, ProfileActivity::class.java)
                        )
                        finish()
                    } else {
                        Toast.makeText(
                            this@LoginActivity,
                            "Invalid login credentials",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                    Toast.makeText(
                        this@LoginActivity,
                        "Network error. Please try again.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }
}
