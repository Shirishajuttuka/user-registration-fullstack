package com.example.peanutapp.api

import com.example.peanutapp.model.LoginResponse
import com.example.peanutapp.model.Trade
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {

    // 1 Login
    @POST("IsAccountCredentialsCorrect")
    fun login(
        @Body body: Map<String, String>
    ): Call<LoginResponse>

    // 2️ Get open trades
    @POST("GetOpenTrades")
    fun getOpenTrades(
        @Body body: Map<String, String>
    ): Call<List<Trade>>
}
