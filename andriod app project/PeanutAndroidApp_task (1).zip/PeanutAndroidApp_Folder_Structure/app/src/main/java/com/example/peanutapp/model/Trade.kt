package com.example.peanutapp.model

import com.google.gson.annotations.SerializedName

data class Trade(

    @SerializedName("symbol")
    val symbol: String?,

    @SerializedName("profit")
    val profit: Double
)
