package com.example.peanutapp.ui

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.peanutapp.R
import com.example.peanutapp.api.ApiClient
import com.example.peanutapp.api.ApiService
import com.example.peanutapp.model.Trade
import com.example.peanutapp.utils.SessionManager
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class TradesActivity : AppCompatActivity() {

    private lateinit var txtTotalProfit: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trades)

        txtTotalProfit = findViewById(R.id.txtTotalProfit)

        loadTrades()
    }

    private fun loadTrades() {

        val token = SessionManager(this).getToken()
        if (token == null) {
            Toast.makeText(this, "Session expired. Please login again.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val requestBody = mapOf(
            "login" to "2088888",
            "token" to token
        )

        val apiService = ApiClient.retrofit.create(ApiService::class.java)

        apiService.getOpenTrades(requestBody)
            .enqueue(object : Callback<List<Trade>> {

                override fun onResponse(
                    call: Call<List<Trade>>,
                    response: Response<List<Trade>>
                ) {
                    if (response.isSuccessful && response.body() != null) {

                        val trades = response.body()!!
                        val totalProfit = trades.sumOf { it.profit }

                        txtTotalProfit.text = "Total Profit: $totalProfit"

                    } else {
                        Toast.makeText(
                            this@TradesActivity,
                            "Failed to load trades",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(call: Call<List<Trade>>, t: Throwable) {
                    Toast.makeText(
                        this@TradesActivity,
                        "Network error",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }
}
