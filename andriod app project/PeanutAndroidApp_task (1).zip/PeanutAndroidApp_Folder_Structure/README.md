Peanut Android Application – Test Task

Developer: [Your Name]
Role: Mobile Android Application Developer
Language: Kotlin

Estimated Completion Time: 3 days
Actual Completion Time: 3 days

------------------------------------
Implemented Features
------------------------------------
1. User authentication using Peanut REST API
2. Secure token storage using SharedPreferences
3. User profile screen
4. Fetching open trades list
5. Total profit calculation from trades
6. Proper error handling
7. Clean and simple UI

------------------------------------
Login Credentials (Test Account)
------------------------------------
Login: 2088888
Password: ral11lod

------------------------------------
How to Run
------------------------------------
1. Open project in Android Studio
2. Let Gradle sync
3. Run on emulator or real device
4. Build APK via Build → Build APK

------------------------------------
Notes
------------------------------------
• Internet connection required
• Handles screen rotation and lifecycle properly
• Production-ready structure
