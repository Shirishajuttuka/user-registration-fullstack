User Registration Full Stack Application
Tech Stack

Frontend: Vue.js
Backend: Spring Boot
Database: MongoDB

Features

User Registration

View All Users

Update User

Delete User

Email uniqueness

REST APIs

MongoDB integration

Backend Setup
Prerequisites

Java 17+

Maven

MongoDB (running on localhost:27017)

Run Backend
mvn clean install
mvn spring-boot:run


Server runs on:

http://localhost:8080

API Endpoints
Create User

POST

http://localhost:8080/api/users


Body:

{
  "fullName": "Shirisha",
  "email": "shirisha@gmail.com",
  "mobile": "9876543210",
  "password": "test123",
  "dob": "2001-01-01"
}

Get All Users

GET

http://localhost:8080/api/users

Update User

PUT

http://localhost:8080/api/users/{id}

Delete User

DELETE

http://localhost:8080/api/users/{id}

MongoDB

Database:

userdb


Collection:

users